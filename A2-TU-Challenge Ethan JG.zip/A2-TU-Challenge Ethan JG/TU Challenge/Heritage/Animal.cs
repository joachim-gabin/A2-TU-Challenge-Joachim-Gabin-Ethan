﻿namespace TU_Challenge.Heritage
{

    public class Animal
    {
        

    }
}
